using System;
using System.Linq;
using System.Windows.Forms;

namespace WinFormsApp3
{
    public partial class SettingsForm : Form
    {
        public SettingsForm()
        {
            InitializeComponent();
            comboBoxTheme.Items.AddRange(ThemeManager.Themes.Keys.ToArray());
            comboBoxTheme.SelectedItem = Properties.Settings.Default.ThemeName;
        }

        private void ButtonApply_Click(object sender, EventArgs e)
        {
            string selectedTheme = comboBoxTheme.SelectedItem.ToString();
            Properties.Settings.Default.ThemeName = selectedTheme;
            Properties.Settings.Default.Save();

            var mainForm = Application.OpenForms.OfType<Form1>().FirstOrDefault();
            if (mainForm != null)
            {
                ThemeManager.ApplyTheme(mainForm, selectedTheme);
            }
            this.Close();
        }
    }
}