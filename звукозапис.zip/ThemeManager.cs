using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace WinFormsApp3
{
    public static class ThemeManager
    {
        public static Dictionary<string, Color> Themes = new()
        {
            {"Світла", Color.White},
            {"Темна", Color.FromArgb(45, 45, 48)},
            {"Вишиванка", Color.LightPink},
            {"Класична", Color.Beige},
            {"Блакитна", Color.LightBlue},
            {"Зелена", Color.LightGreen},
            {"Українська", Color.Yellow}
        };

        public static void ApplyTheme(Form form, string themeName)
        {
            if (Themes.ContainsKey(themeName))
            {
                form.BackColor = Themes[themeName];
            }
        }
    }
}